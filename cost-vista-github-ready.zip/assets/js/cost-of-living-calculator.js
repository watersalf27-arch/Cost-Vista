/* ==========================================================================
   Cost of Living Calculator (prefix: col-)
   Fetches /data/countries-index.json (built by scripts/build.js from the
   per-country JSON files) and computes a live estimate client-side.
   ========================================================================== */
'use strict';

(function () {
  const CATEGORY_LABELS = {
    rent: 'Rent',
    food: 'Food',
    transport: 'Transport',
    utilities: 'Utilities',
    healthcare: 'Healthcare',
  };

  const LIFESTYLE_MULTIPLIERS = {
    budget: 0.72,
    moderate: 1.0,
    comfortable: 1.45,
  };

  const HOUSEHOLD_LABELS = {
    single: 'Single',
    couple: 'Couple',
    family: 'Family of 4',
  };

  let countries = [];
  let state = { slug: null, household: 'single', lifestyle: 'moderate' };

  const el = {
    select: document.getElementById('colCountry'),
    total: document.getElementById('colTotal'),
    resultLabel: document.getElementById('colResultLabel'),
    breakdown: document.getElementById('colBreakdown'),
    guideLink: document.getElementById('colGuideLink'),
    note: document.getElementById('colNote'),
    householdBtns: document.querySelectorAll('[data-household]'),
    lifestyleBtns: document.querySelectorAll('[data-lifestyle]'),
  };

  function currentCountry() {
    return countries.find(c => c.slug === state.slug) || countries[0];
  }

  function render() {
    const country = currentCountry();
    if (!country) {
      el.note.textContent = 'No country data available yet.';
      return;
    }

    const multiplier = LIFESTYLE_MULTIPLIERS[state.lifestyle];
    const baseTotal = country.monthly_costs[state.household];
    const total = Math.round(baseTotal * multiplier);

    el.total.innerHTML = `$${total.toLocaleString()}<small>/mo</small>`;
    el.resultLabel.textContent = `${HOUSEHOLD_LABELS[state.household]} · ${capitalize(state.lifestyle)} — ${country.name}`;

    // Split the total across categories using each category's relative
    // weight (categories.* aren't dollar figures — they're weights, so we
    // normalize against their sum and apply that share to the real total).
    const cats = country.categories;
    const catSum = Object.values(cats).reduce((a, b) => a + b, 0);
    const maxCat = Math.max(...Object.values(cats));

    el.breakdown.innerHTML = Object.entries(cats).map(([key, weight]) => {
      const dollars = Math.round(total * (weight / catSum));
      const widthPct = Math.round((weight / maxCat) * 100);
      return `<div class="col-bar">
        <span>${CATEGORY_LABELS[key] || key}</span>
        <div class="col-bar-track"><div class="col-bar-fill" style="width:${widthPct}%"></div></div>
        <strong>$${dollars.toLocaleString()}</strong>
      </div>`;
    }).join('');

    el.guideLink.href = `/countries/${country.slug}/`;
    el.guideLink.textContent = `See full ${country.name} guide →`;

    el.note.textContent = `Based on researched ${country.currency} cost data for ${country.name}. Estimates only — actual costs vary by city and lifestyle.`;
  }

  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  function setupToggleGroup(buttons, stateKey) {
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('col-active'));
        btn.classList.add('col-active');
        state[stateKey] = btn.dataset[stateKey === 'household' ? 'household' : 'lifestyle'];
        render();
      });
    });
  }

  async function init() {
    try {
      const res = await fetch('/data/countries-index.json');
      if (!res.ok) throw new Error('fetch failed');
      countries = await res.json();
    } catch (e) {
      el.note.textContent = 'Country data is unavailable right now — please try again shortly.';
      el.select.innerHTML = '<option>Unavailable</option>';
      return;
    }

    if (countries.length === 0) {
      el.note.textContent = 'No countries have been added yet — check back soon.';
      return;
    }

    el.select.innerHTML = countries
      .map(c => `<option value="${c.slug}">${c.flag_emoji} ${c.name}</option>`)
      .join('');
    state.slug = countries[0].slug;

    el.select.addEventListener('change', () => {
      state.slug = el.select.value;
      render();
    });

    setupToggleGroup(el.householdBtns, 'household');
    setupToggleGroup(el.lifestyleBtns, 'lifestyle');

    render();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
