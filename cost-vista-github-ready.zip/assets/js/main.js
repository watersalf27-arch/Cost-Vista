'use strict';

/* Theme + mobile nav — global functions since nav buttons across the site
   use onclick="toggleTheme()" / onclick="toggleMobileNav()" directly. */

(function () {
  const root = document.documentElement;
  const saved = window.localStorage ? localStorage.getItem('cv-theme') : null;
  if (saved === 'dark') {
    root.setAttribute('data-theme', 'dark');
  }
  document.addEventListener('DOMContentLoaded', syncThemeIcon);
  syncThemeIcon();

  function syncThemeIcon() {
    const icon = document.getElementById('cv-theme-icon');
    if (icon) icon.textContent = root.getAttribute('data-theme') === 'dark' ? '☀️' : '🌙';
  }

  window.toggleTheme = function () {
    const isDark = root.getAttribute('data-theme') === 'dark';
    if (isDark) {
      root.removeAttribute('data-theme');
      if (window.localStorage) localStorage.setItem('cv-theme', 'light');
    } else {
      root.setAttribute('data-theme', 'dark');
      if (window.localStorage) localStorage.setItem('cv-theme', 'dark');
    }
    syncThemeIcon();
  };
})();

window.toggleMobileNav = function () {
  const links = document.querySelector('.cv-nav-links');
  if (links) links.classList.toggle('cv-nav-links-open');
};
