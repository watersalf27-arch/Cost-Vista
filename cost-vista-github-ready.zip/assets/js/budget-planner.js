/* ==========================================================================
   Budget Planner (prefix: bud-)
   Fetches /data/countries-index.json. Sliders start from each country's
   researched category split (scaled to the chosen household's total monthly
   cost) and can be dragged freely. Nothing is persisted — all in-memory.
   ========================================================================== */
'use strict';

(function () {
  const CATEGORY_LABELS = {
    rent: 'Rent', food: 'Food', transport: 'Transport',
    utilities: 'Utilities', healthcare: 'Healthcare',
  };
  const CATEGORY_ORDER = ['rent', 'food', 'transport', 'utilities', 'healthcare'];

  let countries = [];
  let state = { slug: null, household: 'single', values: {} };

  const el = {
    select: document.getElementById('budCountry'),
    income: document.getElementById('budIncome'),
    sliders: document.getElementById('budSliders'),
    total: document.getElementById('budTotal'),
    annual: document.getElementById('budAnnual'),
    savingsStat: document.getElementById('budSavingsStat'),
    savingsRate: document.getElementById('budSavingsRate'),
    reset: document.getElementById('budReset'),
    note: document.getElementById('budNote'),
    householdBtns: document.querySelectorAll('[data-household]'),
  };

  function currentCountry() {
    return countries.find(c => c.slug === state.slug) || countries[0];
  }

  function defaultsFor(country, household) {
    const total = country.monthly_costs[household];
    const cats = country.categories;
    const catSum = Object.values(cats).reduce((a, b) => a + b, 0);
    const out = {};
    CATEGORY_ORDER.forEach(key => {
      out[key] = Math.round(total * (cats[key] / catSum));
    });
    return out;
  }

  function buildSliders() {
    const country = currentCountry();
    state.values = defaultsFor(country, state.household);
    const maxVal = Object.values(state.values).reduce((a, b) => a + b, 0) * 1.5;

    el.sliders.innerHTML = CATEGORY_ORDER.map(key => `
      <div class="bud-slider-row">
        <label for="budSlider-${key}">${CATEGORY_LABELS[key]}</label>
        <input type="range" id="budSlider-${key}" data-cat="${key}" min="0" max="${Math.round(maxVal)}" step="10" value="${state.values[key]}">
        <span class="bud-slider-value" id="budValue-${key}">$${state.values[key].toLocaleString()}</span>
      </div>
    `).join('');

    el.sliders.querySelectorAll('input[type="range"]').forEach(input => {
      input.addEventListener('input', () => {
        const key = input.dataset.cat;
        state.values[key] = Number(input.value);
        document.getElementById(`budValue-${key}`).textContent = `$${Number(input.value).toLocaleString()}`;
        updateSummary();
      });
    });

    updateSummary();
  }

  function updateSummary() {
    const totalMonthly = Object.values(state.values).reduce((a, b) => a + b, 0);
    el.total.textContent = `$${totalMonthly.toLocaleString()}`;
    el.annual.textContent = `$${(totalMonthly * 12).toLocaleString()}`;

    const income = Number(el.income.value) || 0;
    if (income > 0) {
      const savings = income - totalMonthly;
      const rate = Math.round((savings / income) * 100);
      el.savingsStat.hidden = false;
      el.savingsRate.textContent = `${rate}%`;
      el.savingsRate.style.color = rate < 0 ? 'var(--cv-danger)' : '';
    } else {
      el.savingsStat.hidden = true;
    }

    const country = currentCountry();
    el.note.textContent = `Starting values are based on researched cost data for ${country.name} (${CATEGORY_LABELS ? '' : ''}${state.household === 'family' ? 'family of 4' : state.household}). Drag any slider to customize.`;
  }

  function setupToggleGroup() {
    el.householdBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        el.householdBtns.forEach(b => b.classList.remove('bud-active'));
        btn.classList.add('bud-active');
        state.household = btn.dataset.household;
        buildSliders();
      });
    });
  }

  async function init() {
    try {
      const res = await fetch('/data/countries-index.json');
      if (!res.ok) throw new Error('fetch failed');
      countries = await res.json();
    } catch (e) {
      el.note.textContent = 'Country data is unavailable right now — please try again shortly.';
      el.select.innerHTML = '<option>Unavailable</option>';
      return;
    }

    if (countries.length === 0) {
      el.note.textContent = 'No countries have been added yet — check back soon.';
      return;
    }

    el.select.innerHTML = countries
      .map(c => `<option value="${c.slug}">${c.flag_emoji} ${c.name}</option>`)
      .join('');
    state.slug = countries[0].slug;

    el.select.addEventListener('change', () => {
      state.slug = el.select.value;
      buildSliders();
    });
    el.income.addEventListener('input', updateSummary);
    el.reset.addEventListener('click', buildSliders);

    setupToggleGroup();
    buildSliders();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
