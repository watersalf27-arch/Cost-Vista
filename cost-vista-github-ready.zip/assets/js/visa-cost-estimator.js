/* ==========================================================================
   Visa Cost Estimator (prefix: vis-)
   Fetches /data/countries-index.json. Fee ranges below are general, typical
   industry brackets per traveler-type category (NOT country-specific data —
   clearly disclaimed on the page). The country-specific text comes from
   each country's researched visa_note field.
   ========================================================================== */
'use strict';

(function () {
  const FEE_RANGES = {
    tourist: { label: 'Tourist entry (e-visa / visa-on-arrival)', range: '$0 – $60' },
    nomad:   { label: 'Digital nomad / remote work visa',        range: '$60 – $500' },
    work:    { label: 'Skilled / employer-sponsored work visa',  range: '$150 – $700 (often partly employer-paid)' },
    retire:  { label: 'Retiree / long-stay residency route',     range: '$200 – $2,000+ (may include savings or deposit requirements)' },
  };

  let countries = [];
  let state = { slug: null, type: 'tourist' };

  const el = {
    select: document.getElementById('visCountry'),
    entryBadge: document.getElementById('visEntryBadge'),
    feeRange: document.getElementById('visFeeRange'),
    countryNote: document.getElementById('visCountryNote'),
    guideLink: document.getElementById('visGuideLink'),
    typeBtns: document.querySelectorAll('[data-type]'),
  };

  function currentCountry() {
    return countries.find(c => c.slug === state.slug) || countries[0];
  }

  function render() {
    const country = currentCountry();
    if (!country) return;

    const fee = FEE_RANGES[state.type];
    el.entryBadge.textContent = fee.label;
    el.feeRange.textContent = fee.range;
    el.countryNote.textContent = `${country.flag_emoji} ${country.name}: ${country.visa_note || 'Visa details for this country are being researched — check the full country guide for the latest.'}`;
    el.guideLink.href = `/countries/${country.slug}/`;
    el.guideLink.textContent = `See full ${country.name} guide →`;
  }

  function setupToggleGroup() {
    el.typeBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        el.typeBtns.forEach(b => b.classList.remove('vis-active'));
        btn.classList.add('vis-active');
        state.type = btn.dataset.type;
        render();
      });
    });
  }

  async function init() {
    try {
      const res = await fetch('/data/countries-index.json');
      if (!res.ok) throw new Error('fetch failed');
      countries = await res.json();
    } catch (e) {
      el.countryNote.textContent = 'Country data is unavailable right now — please try again shortly.';
      el.select.innerHTML = '<option>Unavailable</option>';
      return;
    }

    if (countries.length === 0) {
      el.countryNote.textContent = 'No countries have been added yet — check back soon.';
      return;
    }

    el.select.innerHTML = countries
      .map(c => `<option value="${c.slug}">${c.flag_emoji} ${c.name}</option>`)
      .join('');
    state.slug = countries[0].slug;

    el.select.addEventListener('change', () => {
      state.slug = el.select.value;
      render();
    });

    setupToggleGroup();
    render();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
