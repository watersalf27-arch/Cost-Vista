/* ==========================================================================
   Salary Comparison Calculator (prefix: sal-)
   Fetches /data/countries-index.json and compares a user-entered monthly
   salary against a country's average salary and estimated living cost.
   ========================================================================== */
'use strict';

(function () {
  let countries = [];

  const el = {
    income: document.getElementById('salIncome'),
    select: document.getElementById('salCountry'),
    avg: document.getElementById('salAvg'),
    cost: document.getElementById('salCost'),
    leftover: document.getElementById('salLeftover'),
    barFill: document.getElementById('salBarFill'),
    barLabel: document.getElementById('salBarLabel'),
    verdict: document.getElementById('salVerdict'),
    guideLink: document.getElementById('salGuideLink'),
    note: document.getElementById('salNote'),
  };

  function currentCountry() {
    return countries.find(c => c.slug === el.select.value) || countries[0];
  }

  function render() {
    const country = currentCountry();
    if (!country) return;

    const monthlyIncome = Math.max(0, Number(el.income.value) || 0);
    const avgMonthly = Math.round((country.avg_salary_usd || 0) / 12);
    const cost = country.monthly_costs.single;
    const leftover = monthlyIncome - cost;
    const spendShare = monthlyIncome > 0 ? Math.min(100, Math.round((cost / monthlyIncome) * 100)) : 100;

    el.avg.innerHTML = `$${avgMonthly.toLocaleString()}<small>/mo</small>`;
    el.cost.innerHTML = `$${cost.toLocaleString()}<small>/mo</small>`;
    el.leftover.innerHTML = `${leftover < 0 ? '-' : ''}$${Math.abs(leftover).toLocaleString()}<small>/mo</small>`;

    el.barFill.style.width = spendShare + '%';
    el.barLabel.textContent = `${spendShare}% of your salary would go to typical single-person living costs in ${country.name}`;

    let verdict;
    if (leftover < 0) {
      verdict = `Your entered salary is below the typical single-person cost of living in ${country.name} — expect a tight budget.`;
    } else if (spendShare < 35) {
      verdict = `Strong purchasing power — living costs would take up a modest share of your salary in ${country.name}.`;
    } else if (spendShare < 65) {
      verdict = `Comfortable — a reasonable share of your salary goes to typical living costs in ${country.name}.`;
    } else {
      verdict = `Tight — living costs would consume a large share of your salary in ${country.name}.`;
    }
    el.verdict.textContent = verdict;

    el.guideLink.href = `/countries/${country.slug}/`;
    el.guideLink.textContent = `See full ${country.name} guide →`;

    el.note.textContent = `Local average salary and cost-of-living figures are composite editorial estimates for ${country.name}, before tax. Actual salaries vary by industry, seniority and city.`;
  }

  async function init() {
    try {
      const res = await fetch('/data/countries-index.json');
      if (!res.ok) throw new Error('fetch failed');
      countries = await res.json();
    } catch (e) {
      el.note.textContent = 'Country data is unavailable right now — please try again shortly.';
      el.select.innerHTML = '<option>Unavailable</option>';
      return;
    }

    if (countries.length === 0) {
      el.note.textContent = 'No countries have been added yet — check back soon.';
      return;
    }

    el.select.innerHTML = countries
      .map(c => `<option value="${c.slug}">${c.flag_emoji} ${c.name}</option>`)
      .join('');

    el.select.addEventListener('change', render);
    el.income.addEventListener('input', render);

    render();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
