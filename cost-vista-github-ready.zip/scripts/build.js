#!/usr/bin/env node
/**
 * Cost Vista build script
 * Reads /data/countries/*.json, fills /scripts/templates/country.html,
 * writes /countries/<slug>/index.html for each. Also regenerates
 * /sitemap.xml from every country processed.
 *
 * Run: node scripts/build.js
 * (No runtime backend needed — this only runs at build time, output is
 * plain static HTML that GitHub Pages serves as-is.)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data', 'countries');
const CITY_DATA_DIR = path.join(ROOT, 'data', 'cities');
const OUT_DIR = path.join(ROOT, 'countries');
const CITY_OUT_DIR = path.join(ROOT, 'cities');
const TEMPLATE_PATH = path.join(ROOT, 'scripts', 'templates', 'country.html');
const CITY_TEMPLATE_PATH = path.join(ROOT, 'scripts', 'templates', 'city.html');
const SITE_URL = 'https://costvista.example.com'; // TODO: replace with real domain once purchased

const now = new Date();
const CURRENT_YEAR = String(now.getFullYear());
const CURRENT_MONTH_YEAR = now.toLocaleString('en-US', { month: 'long', year: 'numeric' });

// Order + display heading for each known article section key.
// Any key present in article.* but not listed here is skipped (safe for
// future data files that add new keys before build.js is updated).
const SECTION_HEADINGS = [
  ['overview', 'Overview'],
  ['cost_of_living', 'Cost of Living Breakdown'],
  ['best_areas', 'Best Areas to Live'],
  ['transportation', 'Getting Around'],
  ['food', 'Food & Dining'],
  ['safety', 'Safety'],
  ['healthcare', 'Healthcare'],
  ['education', 'Education'],
  ['internet', 'Internet & Remote Work'],
  ['salary_job_market', 'Salary & Job Market'],
  ['visa', 'Visa Requirements'],
  ['tourist_attractions', 'Top Attractions'],
  ['best_time_to_visit', 'Best Time to Visit'],
  ['hidden_gems', 'Hidden Gems'],
];

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Truncate at a word boundary to ~maxLen chars — used for auto-derived
// meta descriptions so we don't need to hand-author one per country.
function truncate(str, maxLen) {
  if (str.length <= maxLen) return str;
  const cut = str.slice(0, maxLen);
  return cut.slice(0, cut.lastIndexOf(' ')) + '…';
}

function buildArticleHtml(article) {
  return SECTION_HEADINGS
    .filter(([key]) => article[key])
    .map(([key, heading]) => `<h2>${heading}</h2>\n    <p>${article[key]}</p>`)
    .join('\n\n  ');
}

function buildFaqHtml(faqs, prefix = 'cty') {
  return (faqs || []).map(f => `<div class="cv-glass ${prefix}-faq-item">
        <h3>${f.q}</h3>
        <p>${f.a}</p>
      </div>`).join('\n      ');
}

function buildFaqJsonLd(faqs) {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: (faqs || []).map(f => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a }
    }))
  }, null, 2);
}

function buildListHtml(items) {
  return (items || []).map(i => `<li>${i}</li>`).join('');
}

// Related countries = up to 3 others in the same region, falling back to
// any other countries if the region doesn't have enough yet. No manual
// related_countries field needed in the data files.
function buildRelatedHtml(current, allData) {
  const sameRegion = allData.filter(d => d.slug !== current.slug && d.region === current.region);
  const others = allData.filter(d => d.slug !== current.slug && d.region !== current.region);
  const picks = [...sameRegion, ...others].slice(0, 3);
  return picks.map(c => `<a class="cv-glass cty-related-card" href="/countries/${c.slug}/">
        <span class="cty-related-flag">${c.flag_emoji}</span>
        <strong>${c.name}</strong>
        <span class="cv-muted">Cost index ${c.cost_index}/100</span>
      </a>`).join('\n      ');
}

function pct(value, categories) {
  const max = Math.max(...Object.values(categories));
  return Math.round((value / max) * 100);
}

function buildCities(citySitemapUrls) {
  if (!fs.existsSync(CITY_DATA_DIR)) return [];
  const files = fs.readdirSync(CITY_DATA_DIR).filter(f => f.endsWith('.json'));
  if (files.length === 0) return [];

  const template = fs.readFileSync(CITY_TEMPLATE_PATH, 'utf8');
  const allCities = files.map(f => JSON.parse(fs.readFileSync(path.join(CITY_DATA_DIR, f), 'utf8')));

  for (const data of allCities) {
    const cats = data.categories;
    const catSum = Object.values(cats).reduce((a, b) => a + b, 0);
    const catDollars = Object.fromEntries(
      Object.entries(cats).map(([k, v]) => [k, Math.round(data.monthly_costs.single * (v / catSum))])
    );
    const metaDescription = truncate(data.article.overview, 155);
    const heroTagline = data.article.overview.split('. ')[0] + '.';

    let html = template;
    const replacements = {
      '{{CITY_NAME}}': data.name,
      '{{SLUG}}': data.slug,
      '{{FLAG}}': data.flag_emoji,
      '{{COUNTRY_NAME}}': data.country_name,
      '{{COUNTRY_SLUG}}': data.country_slug,
      '{{BEST_FOR}}': data.best_for,
      '{{META_DESCRIPTION}}': escapeHtml(metaDescription),
      '{{HERO_TAGLINE}}': heroTagline,
      '{{COST_INDEX}}': data.cost_index,
      '{{SAFETY_SCORE}}': data.safety_score,
      '{{WALKABILITY_SCORE}}': data.walkability_score,
      '{{NIGHTLIFE_SCORE}}': data.nightlife_score,
      '{{DIGITAL_NOMAD_SCORE}}': data.digital_nomad_score,
      '{{QUALITY_OF_LIFE_SCORE}}': data.quality_of_life_score,
      '{{MONTHLY_SINGLE}}': data.monthly_costs.single,
      '{{MONTHLY_COUPLE}}': data.monthly_costs.couple,
      '{{MONTHLY_FAMILY}}': data.monthly_costs.family,
      '{{RENT}}': catDollars.rent,
      '{{FOOD}}': catDollars.food,
      '{{TRANSPORT}}': catDollars.transport,
      '{{UTILITIES}}': catDollars.utilities,
      '{{HEALTHCARE_COST}}': catDollars.healthcare,
      '{{RENT_PCT}}': pct(cats.rent, cats),
      '{{FOOD_PCT}}': pct(cats.food, cats),
      '{{TRANSPORT_PCT}}': pct(cats.transport, cats),
      '{{UTILITIES_PCT}}': pct(cats.utilities, cats),
      '{{HEALTHCARE_PCT}}': pct(cats.healthcare, cats),
      '{{ARTICLE_HTML}}': buildArticleHtml(data.article),
      '{{PROS_HTML}}': buildListHtml(data.article.pros),
      '{{CONS_HTML}}': buildListHtml(data.article.cons),
      '{{FAQ_HTML}}': buildFaqHtml(data.article.faqs, 'cit'),
      '{{FAQ_JSONLD}}': buildFaqJsonLd(data.article.faqs),
      '{{CURRENT_YEAR}}': CURRENT_YEAR,
      '{{CURRENT_MONTH_YEAR}}': CURRENT_MONTH_YEAR,
    };

    for (const [token, value] of Object.entries(replacements)) {
      html = html.split(token).join(value);
    }

    const outDir = path.join(CITY_OUT_DIR, data.slug);
    fs.mkdirSync(outDir, { recursive: true });
    fs.writeFileSync(path.join(outDir, 'index.html'), html, 'utf8');
    console.log(`Built /cities/${data.slug}/`);

    citySitemapUrls.push(`  <url><loc>${SITE_URL}/cities/${data.slug}/</loc><changefreq>monthly</changefreq><priority>0.75</priority></url>`);
  }

  return allCities;
}

function main() {
  if (!fs.existsSync(DATA_DIR)) {
    console.error('No data/countries directory found.');
    process.exit(1);
  }
  const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith('.json'));
  if (files.length === 0) {
    console.log('No country JSON files yet — nothing to build.');
    return;
  }

  const template = fs.readFileSync(TEMPLATE_PATH, 'utf8');
  const allData = files.map(f => JSON.parse(fs.readFileSync(path.join(DATA_DIR, f), 'utf8')));

  const sitemapUrls = [];
  const citySitemapUrls = [];
  const allCities = buildCities(citySitemapUrls);

  for (const data of allData) {
    const cats = data.categories;
    // categories.* are relative weights (not required to sum to 100), used
    // to split the researched single-person monthly total into a per-
    // category dollar estimate — this keeps the breakdown internally
    // consistent with the real monthly_costs figure instead of showing the
    // raw weight number with a misleading "$" in front of it.
    const catSum = Object.values(cats).reduce((a, b) => a + b, 0);
    const catDollars = Object.fromEntries(
      Object.entries(cats).map(([k, v]) => [k, Math.round(data.monthly_costs.single * (v / catSum))])
    );
    const metaDescription = truncate(data.article.overview, 155);
    const heroTagline = data.article.overview.split('. ')[0] + '.';

    let html = template;
    const replacements = {
      '{{COUNTRY_NAME}}': data.name,
      '{{SLUG}}': data.slug,
      '{{FLAG}}': data.flag_emoji,
      '{{REGION}}': data.region,
      '{{CAPITAL}}': data.capital,
      '{{CURRENCY}}': data.currency,
      '{{LANGUAGE}}': data.language,
      '{{POPULATION}}': data.population,
      '{{META_DESCRIPTION}}': escapeHtml(metaDescription),
      '{{HERO_TAGLINE}}': heroTagline,
      '{{COST_INDEX}}': data.cost_index,
      '{{SAFETY_SCORE}}': data.safety_score,
      '{{HEALTHCARE_SCORE}}': data.healthcare_score,
      '{{INTERNET_MBPS}}': data.internet_mbps,
      '{{DIGITAL_NOMAD_SCORE}}': data.digital_nomad_score,
      '{{QUALITY_OF_LIFE_SCORE}}': data.quality_of_life_score,
      '{{MONTHLY_SINGLE}}': data.monthly_costs.single,
      '{{MONTHLY_COUPLE}}': data.monthly_costs.couple,
      '{{MONTHLY_FAMILY}}': data.monthly_costs.family,
      '{{RENT}}': catDollars.rent,
      '{{FOOD}}': catDollars.food,
      '{{TRANSPORT}}': catDollars.transport,
      '{{UTILITIES}}': catDollars.utilities,
      '{{HEALTHCARE_COST}}': catDollars.healthcare,
      '{{RENT_PCT}}': pct(cats.rent, cats),
      '{{FOOD_PCT}}': pct(cats.food, cats),
      '{{TRANSPORT_PCT}}': pct(cats.transport, cats),
      '{{UTILITIES_PCT}}': pct(cats.utilities, cats),
      '{{HEALTHCARE_PCT}}': pct(cats.healthcare, cats),
      '{{ARTICLE_HTML}}': buildArticleHtml(data.article),
      '{{PROS_HTML}}': buildListHtml(data.article.pros),
      '{{CONS_HTML}}': buildListHtml(data.article.cons),
      '{{FAQ_HTML}}': buildFaqHtml(data.article.faqs, 'cty'),
      '{{FAQ_JSONLD}}': buildFaqJsonLd(data.article.faqs),
      '{{RELATED_COUNTRIES_HTML}}': buildRelatedHtml(data, allData),
      '{{CURRENT_YEAR}}': CURRENT_YEAR,
      '{{CURRENT_MONTH_YEAR}}': CURRENT_MONTH_YEAR,
    };

    for (const [token, value] of Object.entries(replacements)) {
      html = html.split(token).join(value);
    }

    const outDir = path.join(OUT_DIR, data.slug);
    fs.mkdirSync(outDir, { recursive: true });
    fs.writeFileSync(path.join(outDir, 'index.html'), html, 'utf8');
    console.log(`Built /countries/${data.slug}/`);

    sitemapUrls.push(`  <url><loc>${SITE_URL}/countries/${data.slug}/</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>`);
  }

  // Base URLs always included
  const baseUrls = [
    `  <url><loc>${SITE_URL}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>`,
    `  <url><loc>${SITE_URL}/countries/</loc><changefreq>weekly</changefreq><priority>0.9</priority></url>`,
    `  <url><loc>${SITE_URL}/cities/</loc><changefreq>weekly</changefreq><priority>0.9</priority></url>`,
    `  <url><loc>${SITE_URL}/tools/</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>`,
    `  <url><loc>${SITE_URL}/tools/cost-of-living-calculator/</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>`,
    `  <url><loc>${SITE_URL}/tools/salary-calculator/</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>`,
    `  <url><loc>${SITE_URL}/tools/visa-cost-estimator/</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>`,
    `  <url><loc>${SITE_URL}/tools/budget-planner/</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>`,
    `  <url><loc>${SITE_URL}/about/</loc><changefreq>yearly</changefreq><priority>0.4</priority></url>`,
    `  <url><loc>${SITE_URL}/contact/</loc><changefreq>yearly</changefreq><priority>0.4</priority></url>`,
    `  <url><loc>${SITE_URL}/privacy-policy/</loc><changefreq>yearly</changefreq><priority>0.2</priority></url>`,
    `  <url><loc>${SITE_URL}/terms/</loc><changefreq>yearly</changefreq><priority>0.2</priority></url>`,
  ];

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${[...baseUrls, ...sitemapUrls, ...citySitemapUrls].join('\n')}
</urlset>
`;
  fs.writeFileSync(path.join(ROOT, 'sitemap.xml'), sitemap, 'utf8');
  console.log(`\nBuilt sitemap.xml with ${baseUrls.length + sitemapUrls.length + citySitemapUrls.length} URLs.`);

  // Compact index for client-side tools (calculator, compare, global search)
  // so they fetch one small file instead of one JSON per country.
  const index = allData.map(d => ({
    slug: d.slug,
    name: d.name,
    flag_emoji: d.flag_emoji,
    region: d.region,
    currency: d.currency,
    cost_index: d.cost_index,
    safety_score: d.safety_score,
    monthly_costs: d.monthly_costs,
    categories: d.categories,
    avg_salary_usd: d.avg_salary_usd,
    visa_note: d.visa_note,
  })).sort((a, b) => a.name.localeCompare(b.name));
  fs.writeFileSync(path.join(ROOT, 'data', 'countries-index.json'), JSON.stringify(index, null, 2), 'utf8');
  console.log(`Built data/countries-index.json with ${index.length} countries.`);

  // Cities index (same idea as countries-index.json, for a future city
  // picker / calculator) — only written if at least one city exists.
  if (allCities.length > 0) {
    const cityIndex = allCities.map(d => ({
      slug: d.slug,
      name: d.name,
      flag_emoji: d.flag_emoji,
      country_name: d.country_name,
      country_slug: d.country_slug,
      cost_index: d.cost_index,
      safety_score: d.safety_score,
      monthly_costs: d.monthly_costs,
      categories: d.categories,
    })).sort((a, b) => a.name.localeCompare(b.name));
    fs.writeFileSync(path.join(ROOT, 'data', 'cities-index.json'), JSON.stringify(cityIndex, null, 2), 'utf8');
    console.log(`Built data/cities-index.json with ${cityIndex.length} cities.`);
  }

  // Search index for the homepage global search box (assets/js/main.js
  // already fetches this — it just didn't exist yet).
  const searchIndex = allData.map(d => ({
    name: d.name,
    flag: d.flag_emoji,
    url: `/countries/${d.slug}/`,
    type: 'Country',
  })).concat(allCities.map(d => ({
    name: `${d.name}, ${d.country_name}`,
    flag: d.flag_emoji,
    url: `/cities/${d.slug}/`,
    type: 'City',
  })));
  fs.writeFileSync(path.join(ROOT, 'data', 'search-index.json'), JSON.stringify(searchIndex, null, 2), 'utf8');
  console.log(`Built data/search-index.json with ${searchIndex.length} entries.`);

  console.log(`Done — ${allData.length} country page(s), ${allCities.length} city page(s) generated.`);
}

main();
